﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4

{
    internal class Course
    {
        public int currentNumberofFaculty = 0;
        public int currentNumberofStudents = 0;
        public string _ClassAbbreviation;
        public string _ClassName;
        public Faculty[] _FacultyID;
        public Student[] _StudentID;
        public string _ClassLocation;
        public DateTime _StartDate;
        public DateTime _EndDate;
        public DateTime _StartTime;
        public DateTime _EndTime;
        public char _Grade;

        public string ClassAbbreviation {
            get { return this._ClassAbbreviation; }
            set { this._ClassAbbreviation = value; }
        }

        public string ClassName {
            get { return this._ClassName; }
            set { this._ClassName = value; }
        }

        public Faculty FacultyID {
            get { return this._FacultyID[currentNumberofFaculty]; }
            set {
                this._FacultyID[currentNumberofFaculty] = value;
                currentNumberofFaculty++;
            }
        }

        public Student StudentID {
            get { return this._StudentID[currentNumberofStudents]; }
            set {
                this._StudentID[currentNumberofStudents] = value;
                currentNumberofStudents++;
            }
        }

        public string ClassLocation {
            get { return this._ClassLocation; }
            set { this._ClassLocation = value; }
        }

        public DateTime StartDate {
            get { return this._StartDate; }
            set { this._StartDate = value; }
        }

        public DateTime EndDate {
            get { return this._EndDate; }
            set { this._EndDate = value; }
        }
        
        public DateTime StartTime{
            get { return this._StartTime;  }
            set { this._StartTime = value; }
        }

        public DateTime EndTime { 
            get { return this._EndTime; }
            set { this._EndTime = value; }
        }

        public char Grade { 
            get { return (char)this._Grade; }
            set { this._Grade = value; }
        }
        public Course(string cN, string cA, 
            Faculty teacher, string cL, DateTime sd, 
            DateTime ed, DateTime st, DateTime et) { 
            
            ClassName = cN;
            ClassAbbreviation = cA;
            _FacultyID[currentNumberofFaculty] = teacher;
            ClassLocation = cL;
            StartDate = sd;
            EndDate = ed;
            StartTime = st;
            EndTime = et;
            Grade = ' ';
        
        }
        public Course(){
            ClassName = String.Empty;
            ClassAbbreviation = String.Empty;
            for (int i = 0; i < 5; i++) {
                _FacultyID[i] = new Faculty();
            }
            for (int i = 0; i < 20; i++) {
                _StudentID[i] = new Student();
            }
            ClassLocation = String.Empty;
            StartDate = DateTime.Now;
            EndDate = DateTime.Now;
            StartTime = DateTime.Now;
            EndTime = DateTime.Now;
            Grade = 'I';
        }

        public void PrintClassRoster() {
            Console.Write("Faculty: ");
            for (int i = 0; i < currentNumberofFaculty; i++){
                if (currentNumberofFaculty == 0){
                    Console.Write("To Be Determined");
                } else {
                    Console.Write(_FacultyID[i]._LastName + ", " + _FacultyID[i]._FirstName + " ");
                }
            }
            Console.WriteLine();
            Console.WriteLine("Students: ");
            for (int i = 0; i < currentNumberofStudents; i++) {
                if (currentNumberofStudents == 0) {
                    Console.WriteLine("Waiting for students to join...");
                } else {
                    Console.WriteLine(_StudentID[i].LastName + ", " + _StudentID[i].FirstName);
                }
            }
        }

        public void CourseInfo() {
            Console.WriteLine("Course: " + _ClassName + " " + _ClassAbbreviation);
            Console.WriteLine("Location: " + _ClassLocation);
            Console.WriteLine("Date: " + Convert.ToString(_StartDate) + " - " + Convert.ToString(_EndDate));
            Console.WriteLine(_StartTime.ToString("hh:mm tt") + " - " + _EndTime.ToString("hh:mm tt"));
        }

        
    }
}
*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4{
    internal class Course{
        public int currentNumberofFaculty = 0;
        public int currentNumberofStudents = 0;
        public string _classAbbreviation;
        public string _className;
        public Faculty[] _facultyID;
        public Student[] _studentID;
        public string _classLocation;
	    public DateTime _startDate;
        public DateTime _endDate;
        public DateTime _startTime;
        public DateTime _endTime;
        public char _grade;

        public string classAbbreviation{
            get { return this._classAbbreviation; }
            set { this._classAbbreviation = value; }
        }

        public string className{
            get { return this._className; }
            set { this._className = value; }
        }

        public Faculty facultyID {
            get { return this._facultyID[currentNumberofFaculty]; }
            set {
                this._facultyID[currentNumberofFaculty] = value;
                currentNumberofFaculty++;
            }
        }

        public Student studentID{
            get { return this._studentID[currentNumberofStudents]; }
            set {
                this._studentID[currentNumberofStudents] = value;
                currentNumberofStudents++;
            }
        }

        public string classLocation{
            get { return this._classLocation; }
            set { this._classLocation = value; }
        }

        public DateTime startDate{
            get { return this._startDate; }
            set { this._startDate = value; }
        }

        public DateTime endDate{
            get { return this._endDate; }
            set { this._endDate = value; }
        }

        public DateTime startTime{
            get { return this._startTime; }
            set { this._startTime = value; }
        }

        public DateTime endTime{
            get { return this._endTime; }
            set { this._endTime = value; }
        }

        public char grade{
            get { return this._grade; }
            set { this._grade = value; }
        }


        public Course(string cN, string cA, Faculty teacher, string cL, DateTime sd, DateTime ed, DateTime st, DateTime et){
            className = cN;
            classAbbreviation = cA;
            _facultyID[currentNumberofFaculty] = teacher;
            classLocation = cL;
            startDate = sd;
            endDate = ed;
            startTime = st;
            endTime = et;
            grade = ' ';

        }

        public Course(){
            className = String.Empty;
            classAbbreviation = String.Empty;
            /*
            for (int i = 0; i < 5; i++){
                _facultyID[i] = new Faculty();
            }
            for (int i = 0; i < 20; i++){
                _studentID[i] = new Student();
            }*/
            classLocation = String.Empty;
            startDate = DateTime.Now;
            endDate = DateTime.Now;
            startTime = DateTime.Now;
            endTime = DateTime.Now;
            grade = 'I';
        }

        public void printClassRoster(){
            Console.Write("Faculty: ");
            for (int i = 0; i < currentNumberofFaculty; i++){
                if (currentNumberofFaculty == 0)
                {
                    Console.Write("To Be Determined");
                } else {
                    Console.Write(_facultyID[i]._lastName + ", " + _facultyID[i]._firstName + " ");
                }
            }

            Console.WriteLine();
            Console.WriteLine("Students: ");
            for (int i = 0; i < currentNumberofStudents; i++){
                if (currentNumberofStudents == 0){
                    Console.WriteLine("Waiting for students to join...");
                } else {
                    Console.WriteLine(_studentID[i]._lastName + ", " + _studentID[i]._firstName);
                }
            }
        }

        public void courseInfo(){
            Console.WriteLine("Course: " + _classAbbreviation + " " + _className);
            Console.WriteLine("Location: " + _classLocation);
            Console.WriteLine("Date: " + Convert.ToString(_startDate) + " - " + Convert.ToString(_endDate));
            Console.WriteLine(_startTime.ToString("hh:mm tt") + "-" + _endTime.ToString("hh:mm tt"));
        }
    }
}