﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    internal class Appointment {

        public DateTime _start;
        public DateTime _end;
        public Student _advisee;
        public Advisors _advisor;
        public string _reason;

        public DateTime start {
            get { return this._start; }
            set { this._start = value; }
        }

        public DateTime end {
            get { return this._end; }
            set { this._end = this._start.AddMinutes(30); }
        }

        public string reason{
            get { return this._reason; }
            set { this._reason = value; }
        }

        Appointment() {
            start = DateTime.Now;
            end = DateTime.Now.AddMinutes(30);
            reason = string.Empty;
            _advisee = new Student();
            _advisor = new Advisors();
        }

        public void PrintAppointment(){
            Console.WriteLine("Advisor: " + _advisor.advisorFirstName + " " + _advisor.advisorLastName);
            Console.WriteLine("Advisee: " + _advisee._firstName + " " + _advisee._lastName);
            Console.WriteLine("Time: " + _start.ToString("hh:mm tt") + " - " + _end.ToString("hh:mm tt"));
            Console.WriteLine("Reason: " + _reason);
        }
    }
}
