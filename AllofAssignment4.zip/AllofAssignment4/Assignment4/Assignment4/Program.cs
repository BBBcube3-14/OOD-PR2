﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;

namespace Assignment4 {
    internal class Program {
        static void Main(string[] args) {
            int currentNumberOfStudents = 0;
            int currentNumberOfAdvisors = 0;
            int currentNumberOfFaculty = 0;
            int currentNumberOfCourses = 0;
            Student[] students = new Student[100];
            for (int i = 0; i < 100; i++) {
                students[i] = new Student();
            }
            Advisors[] advisors = new Advisors[10];
            Faculty[] faculty = new Faculty[10];
            for (int i = 0; i < 10; i++){
                advisors[i] = new Advisors();
                faculty[i] = new Faculty();
            }
            Course[] courses = new Course[50];
            for (int i = 0; i < 50; i++){
                courses[i] = new Course();
            }
            int input = 1;
            
            while (input != 0) {
                Console.WriteLine("Enter a number for the role you are?");
                Console.WriteLine("1. Student\n2. Faculty\n3. Advisor\n 0. Quit\n");
                input = Convert.ToInt16(Console.ReadLine());
                //input = Convert.ToInt16(Console.ReadLine());
                if (input == 1) {
                    Console.Clear();
                    Console.WriteLine("Welcome Student");
                    Console.WriteLine("What do you want to do?:");
                    Console.WriteLine("1. Add Student");
                    Console.WriteLine("2. Register for Classes");
                    Console.WriteLine("3. View Classes");
                    Console.WriteLine("4. Print student info");
                    Console.WriteLine("5. Add Appointment");
                    input = Convert.ToInt16(Console.ReadLine());

                    if (input == 1)
                    {
                        students[currentNumberOfStudents] = new Student
                        {
                            studentID = currentNumberOfStudents + 1
                        };
                        Console.WriteLine("Enter your first name: ");
                        string fName = Console.ReadLine();
                        students[currentNumberOfStudents].firstName = fName;
                        Console.WriteLine("Enter your last name: ");
                        string lName = Console.ReadLine();
                        students[currentNumberOfStudents].lastName = lName;
                        Console.WriteLine("Enter you mailing address: ");
                        string mA = Console.ReadLine();
                        students[currentNumberOfStudents].mailAddress = mA;
                        Console.WriteLine("Enter your City: ");
                        string City = Console.ReadLine();
                        students[currentNumberOfStudents].city = City;
                        Console.WriteLine("Enter your State: ");
                        string State = Console.ReadLine();
                        students[currentNumberOfStudents].state = State;
                        Console.WriteLine("Enter your zip code: ");
                        string zip = Console.ReadLine();
                        students[currentNumberOfStudents].zipCode = zip;
                        Console.WriteLine("Enter your Major: ");
                        string Major = Console.ReadLine();
                        students[currentNumberOfStudents].major = Major;
                        Console.WriteLine("Enter your Start date: ");
                        DateTime Start = Convert.ToDateTime(Console.ReadLine());
                        students[currentNumberOfStudents].startDate = Start;

                        currentNumberOfStudents++;
                        //input = 500;
                    }
                    else if (input == 2)
                    {
                        Console.WriteLine("Enter your studentID");
                        int id = Convert.ToInt16(Console.ReadLine());
                        Console.WriteLine("Add a class from the following options. Enter the class abbreviation. E.g. CSC105");
                        for (int i = 0; i < currentNumberOfCourses; i++)
                        {
                            courses[i].courseInfo();
                        }
                        string classPicked = Console.ReadLine();
                        
                        for (int i = 0; i < currentNumberOfCourses; i++) {
                            if (classPicked == courses[i]._classAbbreviation){
                                students[id].classes[students[i].currentClassesEnrolled] = courses[i];
                                courses[i]._studentID[courses[i].currentNumberofStudents] = students[id];
                                courses[i].currentNumberofStudents++;
                                students[id].currentClassesEnrolled++;
                                break;
                            }
                        }
                    } else if (input == 3) {
                        Console.WriteLine("Enter your studentID");
                        int id = Convert.ToInt16(Console.ReadLine());
                        for (int i = 0; i < students[id].currentClassesEnrolled; i++) {
                            students[id].classes[i].courseInfo();
                            Console.WriteLine();
                        }
                    } else if (input == 4) {
                        Console.WriteLine("Enter a student ID: ");
                        input = Convert.ToInt16(Console.ReadLine());
                        students[input - 1].PrintInfo();
                    } else if (input == 5) {
                        Console.WriteLine("Enter the advisorID of whom you wish to speak: ");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter your studentID: ");
                        int sID = Convert.ToInt32(Console.ReadLine()) - 1;
                        Console.WriteLine("When do you want an appointment: ");
                        DateTime app = Convert.ToDateTime(Console.ReadLine());
                        Console.WriteLine("Enter a breif reason for the appointment: ");
                        string reason = Console.ReadLine();
                        advisors[id - 1].appointments.start = app;
                        advisors[id - 1].appointments.end = app.AddMinutes(30);
                        advisors[id - 1].appointments._advisee = students[sID];
                        advisors[id - 1].appointments._advisor = advisors[id - 1];
                        advisors[id - 1].appointments.reason = reason;
                        advisors[id - 1].currentNumberofAppointments++;
                    }
                } else if (input == 2) {
                    Console.Clear();
                    Console.WriteLine("Welcome Faculty\n");
                    Console.WriteLine("What do you want to do?:");
                    Console.WriteLine("1. Add Faculty.");
                    Console.WriteLine("2. View Schedule");
                    Console.WriteLine("3. Update Faculty Information.");
                    Console.WriteLine("4. View Faculty Information.");
                    Console.WriteLine("5. Add Course.");
                    input = Convert.ToInt16(Console.ReadLine());
                    if (input == 1){
                        faculty[currentNumberOfFaculty].facultyID = currentNumberOfFaculty + 1;
                        Console.WriteLine("Enter your first name: ");
                        string fFName = Console.ReadLine();
                        faculty[currentNumberOfFaculty].firstName = fFName;
                        Console.WriteLine("Enter your last name: ");
                        string fLName = Console.ReadLine();
                        faculty[currentNumberOfFaculty].lastName = fLName;

                        currentNumberOfFaculty++;
                    }else if (input == 2){
                        Console.WriteLine("Enter a faculty ID: ");
                        input = Convert.ToInt16(Console.ReadLine());
                        faculty[input - 1].printSchedule();
                    }else if (input == 3) {
                        Console.Clear();
                        Console.WriteLine("Update Faculty Information");
                        Console.WriteLine("Enter a FacultyID: ");
                        int id = Convert.ToInt16(Console.ReadLine());
                        Console.WriteLine("1. First Name");
                        Console.WriteLine("2. Last Name");
                        input = Convert.ToInt16(Console.ReadLine());
                        if (input == 1) {
                            Console.WriteLine("Enter your new first name");
                            string fName = Console.ReadLine();
                            Console.WriteLine("Old: " + faculty[id - 1]._firstName + " " + faculty[id - 1]._lastName);
                            Console.WriteLine("New: " + fName + " " + faculty[id-1]._lastName);
                            Console.WriteLine("Confirm: y/n");
                            char cinput = Convert.ToChar(Console.ReadLine());
                            if (cinput == 'y'){
                                faculty[id - 1].firstName = fName;
                            }
                        } else if(input == 2){
                            Console.WriteLine("Enter your new last name");
                            string lName = Console.ReadLine();
                            Console.WriteLine("Old: " + faculty[id - 1]._firstName + " " + faculty[id - 1]._lastName);
                            Console.WriteLine("New: " + faculty[id - 1]._firstName + " " + lName);
                            Console.WriteLine("Confirm: y/n");
                            char cinput = Convert.ToChar(Console.ReadLine());
                            if (cinput == 'y'){
                                faculty[id - 1].lastName = lName;
                            }
                        }
                    } else if (input == 4) {
                        Console.WriteLine("Enter a faculty ID: ");
                        input = Convert.ToInt16(Console.ReadLine());
                        faculty[input - 1].printInfo();
                    } else if (input == 5) {
                        Console.WriteLine("Enter a FacultyID: ");
                        input = Convert.ToInt16(Console.ReadLine());
                        courses[currentNumberOfCourses].facultyID = faculty[input - 1];
                        Console.WriteLine("Enter a class abbreviation: ABC-123");
                        string courseAbbreviation = Console.ReadLine();
                        courses[currentNumberOfCourses].classAbbreviation = courseAbbreviation;
                        Console.WriteLine("Enter a class name: ");
                        string courseName = Console.ReadLine();
                        courses[currentNumberOfCourses].className = courseName;
                        Console.WriteLine("Enter the location of the class: ");
                        string courseLocation = Console.ReadLine();
                        courses[currentNumberOfCourses].classLocation = courseLocation;
                        Console.WriteLine("Enter a Start date: ");
                        DateTime StartD = Convert.ToDateTime(Console.ReadLine());
                        courses[currentNumberOfCourses].startDate = StartD;
                        Console.WriteLine("Enter an End date: ");
                        DateTime EndD = Convert.ToDateTime(Console.ReadLine());
                        courses[currentNumberOfCourses].endDate = EndD;
                        Console.WriteLine("Enter the time class Starts: HH:mm tt");
                        DateTime StartT = Convert.ToDateTime(Console.ReadLine());
                        courses[currentNumberOfCourses].startTime = StartT;
                        Console.WriteLine("Enter the time class Ends: HH:mm tt");
                        DateTime EndT = Convert.ToDateTime(Console.ReadLine());
                        courses[currentNumberOfCourses].endTime = EndT;

                        faculty[currentNumberOfFaculty].courses[currentNumberOfCourses] = new Course(courseName, courseAbbreviation, faculty[input - 1], courseLocation, StartD, EndD, StartT, EndT);
                        currentNumberOfCourses++;
                        faculty[currentNumberOfFaculty].currentNumberofCourses++;
                        //faculty[input - 1].PrintInfo();
                    }
                } else if (input == 3) {
                    Console.Clear();
                    Console.WriteLine("Welcome Advisor\n");
                    Console.WriteLine("What do you want to do?:");
                    Console.WriteLine("1. Add Advisor.");
                    Console.WriteLine("2. View Schedule");
                    Console.WriteLine("3. Update Advisor Information.");
                    Console.WriteLine("4. View Advisor Information.");
                    input = Convert.ToInt16(Console.ReadLine());
                    if (input == 1)
                    {
                        advisors[currentNumberOfAdvisors].advisorID = currentNumberOfAdvisors + 1;
                        Console.WriteLine("Enter your first name: ");
                        string aFName = Console.ReadLine();
                        advisors[currentNumberOfAdvisors].advisorFirstName = aFName;
                        Console.WriteLine("Enter your last name: ");
                        string aLName = Console.ReadLine();
                        advisors[currentNumberOfAdvisors].advisorLastName = aLName;
                        Console.WriteLine("Enter the Major you will be advising: ");
                        string major = Console.ReadLine();
                        advisors[currentNumberOfAdvisors].major = major;

                        currentNumberOfAdvisors++;

                    } else if (input == 2) {
                        Console.WriteLine("Enter an advisor ID: ");
                        int id = Convert.ToInt16(Console.ReadLine());
                        for (int i = 0; i < advisors[id - 1].currentNumberofAppointments; i++) {
                            advisors[id - 1].appointments.PrintAppointment();
                        }
                    } else if (input == 3){
                        Console.WriteLine("Enter an advisor ID: ");
                        int id = Convert.ToInt16(Console.ReadLine());
                        Console.WriteLine("What field do you wat to edit: ");
                        Console.WriteLine("1. First Name\n2. Second Name\n3. Major");
                        input = Convert.ToInt16(Console.ReadLine());
                        if (input == 1) {
                            Console.WriteLine("Enter your new first name");
                            string fName = Console.ReadLine();
                            Console.WriteLine("Old: " + advisors[id - 1]._advisorFirstName + " " + advisors[id - 1]._advisorLastName);
                            Console.WriteLine("New: " + fName + " " + advisors[id - 1]._advisorLastName);
                            Console.WriteLine("Confirm: y/n");
                            char cinput = Convert.ToChar(Console.ReadLine());
                            if (cinput == 'y')
                            {
                                advisors[id - 1].advisorFirstName = fName;
                            }
                        } else if (input == 2) {
                            Console.WriteLine("Enter your new last name");
                            string lName = Console.ReadLine();
                            Console.WriteLine("Old: " + advisors[id - 1]._advisorFirstName + " " + advisors[id - 1]._advisorLastName);
                            Console.WriteLine("New: " + advisors[id - 1]._advisorFirstName + " " + lName);
                            Console.WriteLine("Confirm: y/n");
                            char cinput = Convert.ToChar(Console.ReadLine());
                            if (cinput == 'y')
                            {
                                advisors[id - 1].advisorLastName = lName;
                            }
                        } else if ( input == 3) {
                            Console.WriteLine("Enter your new major");
                            string major = Console.ReadLine();
                            Console.WriteLine("Old " + advisors[id - 1]._major);
                            Console.WriteLine("New " + advisors[id - 1]._major);
                            char cinput = Convert.ToChar(Console.ReadLine());
                            if (cinput == 'y')
                            {
                                advisors[id - 1].major = major;
                            }
                        }

                        /*
                         if (input == 1) {
                            Console.WriteLine("Enter your new first name");
                            string fName = Console.ReadLine();
                            Console.WriteLine("Old: " + faculty[id - 1]._firstName + " " + faculty[id - 1]._lastName);
                            Console.WriteLine("New: " + fName + " " + faculty[id-1]._lastName);
                            Console.WriteLine("Confirm: y/n");
                            char cinput = Convert.ToChar(Console.ReadLine());
                            if (cinput == 'y'){
                                faculty[id - 1].firstName = fName;
                            }
                        } else if(input == 2){
                            Console.WriteLine("Enter your new last name");
                            string lName = Console.ReadLine();
                            Console.WriteLine("Old: " + faculty[id - 1]._firstName + " " + faculty[id - 1]._lastName);
                            Console.WriteLine("New: " + faculty[id - 1]._firstName + " " + lName);
                            Console.WriteLine("Confirm: y/n");
                            char cinput = Convert.ToChar(Console.ReadLine());
                            if (cinput == 'y'){
                                faculty[id - 1].lastName = lName;
                            }
                        }
                         */

                    }
                    else if (input == 4) {
                        Console.WriteLine("Enter an advisor ID: ");
                        input = Convert.ToInt16(Console.ReadLine());
                        advisors[input - 1].printInfo();
                    }
                }
            }
        }
    }
}
