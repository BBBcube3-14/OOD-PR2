﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    internal class Advisors
    {
        public int currentNumberofAppointments = 0;
        public int _advisorID;
        public string _advisorFirstName;
        public string _advisorLastName;
        public string _major;
        public Appointment[] _appointments;
        

        public int advisorID {
            get { return this._advisorID; }
            set { this._advisorID = value; }
        }
        public string advisorFirstName {
            get { return this._advisorFirstName; }
            set { this._advisorFirstName = value; }
        }

        public string advisorLastName { 
            get { return this._advisorLastName; }
            set { this._advisorLastName = value;}
        }

        public string major {
            get { return this._major; }
            set { this._major = value; }
        }

        public Appointment appointments { 
            get { return this._appointments[currentNumberofAppointments];  }
            set {
                this._appointments[currentNumberofAppointments] = value;
                currentNumberofAppointments++;
            }
        }

        
        public Advisors() { 
            advisorID = 0;
            advisorFirstName = string.Empty; 
            advisorLastName = string.Empty;
            major = string.Empty;
            
        }

        public void printInfo() {
            Console.WriteLine("Name: " + _advisorFirstName + " " + _advisorLastName);
            Console.WriteLine("Advising major: " + _major);
        }
    }
}
