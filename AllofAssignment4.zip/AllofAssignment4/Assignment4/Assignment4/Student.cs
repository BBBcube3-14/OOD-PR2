﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    internal class Student {
        public int _studentID;
        public string _firstName;
        public string _lastName;
        public string _mailAddress;
        public string _city;
        public string _state;
        public string _zipCode;
        public string _major;
        public int _advisorID;
        private string tempAdvisor;
        public DateTime _startDate;
        public DateTime _endDate;
        public Course[] classes;
        public int currentClassesEnrolled = 0;
        
        public int studentID { 
            get { return this._studentID; } 
            set { this._studentID = value; }
        }
        public string firstName {
            get { return this._firstName; }
            set { this._firstName = value; }
        }
        public string lastName {
            get { return this._lastName; }
            set { this._lastName = value; }
        }
        public string mailAddress {
            get { return this._mailAddress; }
            set { this._mailAddress = value; }
        }
        public string city {
            get { return this._city; }
            set { this._city = value; }
        }
        public string state {
            get { return this._state; }
            set { this._state = value; }
        }
        public string zipCode {
            get { return this._zipCode; }
            set { this._zipCode = value; }
        }
        public string major {
            get { return this._major; }
            set {                 
                if (value == null) {
                    this._major = "General Studies";
                } else {
                    this._major = value;
                }

                if (this.major == "Computers"){
                    tempAdvisor = "1";
                }else if (this.major == "Education"){
                    tempAdvisor = "2";
                } else {
                    tempAdvisor = "3";
                }
                
            }
        }
        
        public int advisorID {
            get { return this._advisorID; }
            set { this._advisorID = Convert.ToInt32(tempAdvisor); }
        }
        
        public DateTime startDate {
            get { return this._startDate; }
            set { this._startDate = value; }
        }

        public DateTime endDate { 
            get { return this._endDate; }
            set { this._endDate = this._startDate.AddDays(365 * 3 + 180); }
        }

        public Student() { 
            studentID = 0;
            firstName = string.Empty;
            lastName = string.Empty;
            mailAddress = string.Empty;
            city = string.Empty;
            state = string.Empty;
            zipCode = string.Empty;
            major = string.Empty;
            advisorID = 0;
            startDate = DateTime.Now;
            endDate = DateTime.Now.AddDays(365 * 3 + 180);         
        }

        public void PrintInfo() {
            Console.WriteLine("Name: " + _lastName + ", " + _firstName + " Stuent ID: " + _studentID);
            Console.WriteLine("Address: " + _mailAddress + " " +  _city + ", " + _state + ", " + _zipCode);
            Console.WriteLine("Start date: " + Convert.ToString(_startDate) + " End date: " + Convert.ToString(_endDate) );
        }
    }
}
