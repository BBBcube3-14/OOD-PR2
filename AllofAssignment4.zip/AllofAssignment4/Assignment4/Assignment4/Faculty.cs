﻿/*
{
    internal class Faculty {
        public int currentNumberofCourses = 0;
        public int _FacultyID;
        public string _FirstName;
        public string _LastName;
        public Course[] courses = new Course[5];


        
        //for (int i = 0; i < 5; i++){
        //     course[i] = new Courses();
        //}

        public int FacultyID { 
            get { return this._FacultyID; } 
            set { this._FacultyID = value; }
        }
        public string FirstName
        {
            get { return this._FirstName; }
            set { this._FirstName = value; }
        }
        public string LastName { 
            get { return this._LastName; }
            set { this._LastName = value; }
        }
        public Faculty(){
            FacultyID = 0;
            FirstName = string.Empty;
            LastName = string.Empty;
        }
    
        public void PrintInfo() { 
            Console.WriteLine("Name: " + _FirstName + " " + _LastName + " ID#: " + _FacultyID);
        }

        public void PrintSchedule() {
            Console.WriteLine(courses[0].StartDate + " - " + courses[0].EndDate);
            for (int i = 0; i < 5; i++) {
                Console.WriteLine(courses[i].ClassAbbreviation + " " + courses[i].ClassName);
                Console.WriteLine(courses[i].StartTime + "-" + courses[i].EndTime);
            }
            
        }
    }
}
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4{
    internal class Faculty {
        public int currentNumberofCourses = 0;
        public int _facultyID;
        public string _firstName;
        public string _lastName;
        public Course[] courses = new Course[5];
        //Course[] classes = new Course[5];
        //for (int i = 0; i < 5; i++){

        //}
        

        public int facultyID{
            get { return this._facultyID; }
            set { this._facultyID = value; }
        }

        public string firstName{
            get { return this._firstName; }
            set { this._firstName = value; }
        }
        public string lastName{
            get { return this._lastName; }
            set { this._lastName = value; }
        }

        public Faculty(){
            facultyID = 0;
            firstName = string.Empty;
            lastName = string.Empty;
        }

        public void printInfo(){
            Console.WriteLine("Name: " + _firstName + " " + _lastName + " ID#: " + _facultyID);
        }

        public void printSchedule(){
            Console.WriteLine(courses[0]._startDate + " - " + courses[0]._endDate);
            for (int i = 0; i < 5; i++){
                Console.WriteLine(courses[i]._classAbbreviation + " " + courses[i]._className);
                Console.WriteLine(Convert.ToString(courses[i]._startTime) + "-" + Convert.ToString(courses[i]._endTime));
            }
        }
    }
}